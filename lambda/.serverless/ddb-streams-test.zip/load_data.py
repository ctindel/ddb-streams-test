import boto3
import uuid
import datetime
import time

DDB_ITEM_COUNT=100000
if 'DDB_ITEM_COUNT' in os.environ:
    DDB_ITEM_COUNT = os.environ['DDB_ITEM_COUNT']

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ddb-streams-test')
while DDB_ITEM_COUNT > 0:
    item = {
        'pk': str(uuid.uuid4()),
        'insertTime': datetime.datetime.now().isoformat() + 'Z'
    }
    
    response = table.put_item(
       Item=item
    )
    if response.ResponseMetadata.HTTPStatusCode != 200:
        time.sleep(1)
    else:
        
    print(response)


